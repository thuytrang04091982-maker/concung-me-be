
import { createClient } from '@supabase/supabase-js';

// LẤY BIẾN MÔI TRƯỜNG TỪ NETLIFY HOẶC GIÁ TRỊ TẠM THỜI
const supabaseUrl = (window as any).process?.env?.SUPABASE_URL || '';
const supabaseAnonKey = (window as any).process?.env?.SUPABASE_ANON_KEY || '';

// Kiểm tra nếu URL hợp lệ (phải bắt đầu bằng http) để tránh lỗi "Invalid URL"
const isValidUrl = supabaseUrl && supabaseUrl.startsWith('http');

export const supabase = isValidUrl 
  ? createClient(supabaseUrl, supabaseAnonKey) 
  : null as any;

if (!isValidUrl) {
  console.warn("⚠️ Supabase chưa được cấu hình! Vui lòng điền SUPABASE_URL và SUPABASE_ANON_KEY trong lib/supabase.ts hoặc cấu hình trên Netlify.");
}
